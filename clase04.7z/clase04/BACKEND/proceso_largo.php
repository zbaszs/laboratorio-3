<?php
//PROVOCO UN RETARDO EN EL SERVIDOR, SIMULANDO UN PROCESO LARGO...
sleep(8);

echo "Proceso listo!!!";
