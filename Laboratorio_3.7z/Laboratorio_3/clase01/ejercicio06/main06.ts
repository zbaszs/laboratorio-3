console.log("El cubo de 3 es : "+MostrarCuboNumero(3));
console.log("El cubo de 1 es : "+MostrarCuboNumero(1));
console.log("El cubo de 2 es : "+MostrarCuboNumero(2));