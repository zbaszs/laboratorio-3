function MostrarCuboNumero(numero:number):number
{
    return Math.pow(numero,3);
}