console.log(Funcionaza(4));
console.log(Funcionaza(15));
console.log(Funcionaza(1));