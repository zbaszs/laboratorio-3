CuboFactorial(9);
console.log("Numero: -9 Cubo: "+CuboFactorial(-9));