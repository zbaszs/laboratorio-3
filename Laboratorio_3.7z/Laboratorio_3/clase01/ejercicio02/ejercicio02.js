var meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
for (var i = 0; i < meses.length; i++) {
    console.log("mes : " + i + " - " + meses[i]);
}
