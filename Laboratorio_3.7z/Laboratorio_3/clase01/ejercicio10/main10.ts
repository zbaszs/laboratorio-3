console.log(ComprobarPalabra("pedo"));
console.log(ComprobarPalabra("PeDo"));
console.log(ComprobarPalabra("PEDO"));