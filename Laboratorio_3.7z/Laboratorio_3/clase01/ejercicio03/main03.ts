MostrarNumeroPalabra(4,"hola");
MostrarNumeroPalabra(14);