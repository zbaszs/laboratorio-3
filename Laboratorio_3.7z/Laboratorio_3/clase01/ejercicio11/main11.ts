console.log(Palindromos("la ruta nos aporto otro paso natural"));
console.log(Palindromos("la ruta se tira pedos"));