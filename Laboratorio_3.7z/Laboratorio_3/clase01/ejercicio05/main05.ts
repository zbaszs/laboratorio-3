console.log(MostrarNombreApellido("lautaro","medeiros"));
console.log(MostrarNombreApellido("franco","salas"));