console.log(SignoZodiaco("1-12-2019"));
console.log(SignoZodiaco("19-10-2019"));
console.log(SignoZodiaco("20-9-2019"));
