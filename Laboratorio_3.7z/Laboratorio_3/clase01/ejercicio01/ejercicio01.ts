var msj1 :string=" HOLA MUNDO!!!\n";
var msj2 :string="Puedo mostrar comillas 'simples'\n";
var msj3 :string="Y comillas ´dobles´";
console.log(msj1+" "+msj2+" "+msj3);