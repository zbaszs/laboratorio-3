var msj1 = " HOLA MUNDO!!!\n";
var msj2 = "Puedo mostrar comillas 'simples'\n";
var msj3 = "Y comillas ´dobles´";
console.log(msj1 + " " + msj2 + " " + msj3);
