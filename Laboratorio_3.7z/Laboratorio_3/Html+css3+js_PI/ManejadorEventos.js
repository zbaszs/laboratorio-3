window.onload=M;
function M()
{
    document.getElementById("e").addEventListener("click",Mensajito,false);
}

function Mensajito()
{
    alert("Que onda maquina");
}