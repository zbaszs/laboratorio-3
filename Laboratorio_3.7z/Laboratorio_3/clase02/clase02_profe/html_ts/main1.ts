
function Click():void {
    alert("desde funcion...");
}

class Manejadora{

    public static Click():void {
        alert("desde clase...");
    }

}
